# Student-Database-Management-System
This is project of our sophomore project of Data Base Management System made using Python and Sqlite.
In this student database management system we can add, delete,update,view and clear existing records from the database.
Here Student ID acts as the PRIMARY KEY and we store Student name,age,gender,address and mobile number.<br />
Here are some of the screenshots of the frontend:
 <br />
![Screenshot (47)](https://user-images.githubusercontent.com/45651397/78636372-d96e5b00-78c5-11ea-93ee-c195c5b8ee9a.png)
 <br />
Here Add new- Adds new informtion related to student.<br />
Clear- clears the entry box for new entries.<br />
Search- Enter any keyword in the query box and search will show you the relevant results.<br />
Update- Updates any changes applied to that particular given user.<br />
Delete- Deletes the entire dataset selected.<br />
Display- Views the entries till date.<br />
Here is how the Exit button works:<br />
 <br />
![Screenshot (48)](https://user-images.githubusercontent.com/45651397/78637910-f7898a80-78c8-11ea-8f47-44dba9b0ae74.png)
 <br />
If we press 'Yes'  it will exit the process and if we press 'No' it will return to process.<br />
This project was undertaken under the guidance of Dr. Brij Bihari Dubey of the Database Management Systems.<br />
Language used: Python 3<br />
Query Language used: Sqlite 3<br />
Library:Tkinter<br />
Other concepts involved: Object Oriented Programming(OOPS)


